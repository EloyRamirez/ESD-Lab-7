/*
 * Lab6_Part4.c
 *
 *  Created on: Apr 25, 2022
 *      Author: liann
 */

#include "io.h"
#include <stdio.h>
#include "system.h"

// create standard embedded type definitions
typedef   signed char   sint8;              // signed 8 bit values
typedef unsigned char   uint8;              // unsigned 8 bit values
typedef   signed short  sint16;             // signed 16 bit values
typedef unsigned short  uint16;             // unsigned 16 bit values
typedef   signed long   sint32;             // signed 32 bit values
typedef unsigned long   uint32;             // unsigned 32 bit values
typedef         float   real32;             // 32 bit real values

volatile uint32 *ledsBase_ptr     = (uint32 *) LEDS_BASE;
volatile uint32 *key1Base_ptr	   = (uint32*)KEY1_BASE;
volatile uint32 *pushButton;
uint8 *infRam8_ptr = (uint8*)INFERRED_RAM_BE_0_BASE;
uint16 *infRam16_ptr = (uint16*)INFERRED_RAM_BE_0_BASE;
uint32 *infRam32_ptr = (uint32*)INFERRED_RAM_BE_0_BASE;

//temp storage
unsigned char led_val;

void bitReset(uint32 *address, uint32 ramSize, uint32 testData)
{

	uint32 ramTestLoc;

	for(int i=address; i<ramSize; i++)
	{
		*(address + i) = testData;
	}
}

void bitTest8(uint8 *address, unsigned int ramSize, uint8 testData)
{
	uint32 ramTestLoc;

		for(int i=address; i<ramSize; i++)
		{
			*(address + i) = testData;
		}

		for(int i=address; i<ramSize; i++)
		{
			ramTestLoc = *(address +i);

			if (ramTestLoc != testData)
			{
				printf("\n\nERROR: Address: %u Read: %u Expected: %u ",i,(ramTestLoc),testData);
				*ledsBase_ptr = 0xFF;

			}
		}
}

void bitTest16(uint16 *address, unsigned int ramSize, uint16 testData)
{
	uint32 ramTestLoc;

		for(int i=address; i<ramSize/2; i++)
		{
			*(address + i) = testData;
		}

		for(int i=address; i<ramSize/2; i++)
		{
			ramTestLoc = *(address +i);

			if (ramTestLoc != testData)
			{
				printf("\n\nERROR: Address: %u Read: %u Expected: %u ",i,(ramTestLoc),testData);
				*ledsBase_ptr = 0xFF;

			}
		}
}

void bitTest32(uint32 *address, unsigned int ramSize, uint32 testData)
{

	uint32 ramTestLoc;

	for(int i=address; i<ramSize/4; i++)
	{
		*(address + i) = testData;
	}

	for(int i=address; i<ramSize/4; i++)
	{
		ramTestLoc = *(address +i);

		if (ramTestLoc != testData)
		{
			printf("\n\nERROR: Address: %u Read: %u Expected: %u ",i,(ramTestLoc),testData);
			*ledsBase_ptr = 0xFF;

		}
	}
}


int main(void)
/*****************************************************************************/
/* Main Program                                                              */
/*   Enables interrupts then loops infinitely                                */
/*****************************************************************************/
{
    /* this enables the NIOS II to accept a TIMER interrupt
     * and indicates the name of the interrupt handler */

	*ledsBase_ptr = 0x00;

	bitReset(INFERRED_RAM_BE_0_BASE, 4096, 0x00);

    while(1)
    {
    	bitTest8(infRam8_ptr, 4096, 0xE1);
    	*ledsBase_ptr = 0x00;
    	bitReset(INFERRED_RAM_BE_0_BASE, 4096, 0x00);

    	bitTest16(infRam16_ptr, 4096, 0x0EE1);
    	*ledsBase_ptr = 0x00;
    	bitReset(INFERRED_RAM_BE_0_BASE, 4096, 0x00);

    	bitTest32(infRam32_ptr, 4096, 0xE10E1234);
    	*ledsBase_ptr = 0x00;
    	bitReset(INFERRED_RAM_BE_0_BASE, 4096, 0x00);

    	pushButton = *key1Base_ptr;

    	    if (pushButton == 0)
    	    {
    	    	while (pushButton != 1)
    	    	{
    	    		pushButton = *key1Base_ptr;
    	    	}
    	    	pushButton = *key1Base_ptr;
    	    	*ledsBase_ptr = 0x333;
    	    	printf((uint8*)"\n\nRAM TEST DONE");
    	    }
    }

    return 0;
}
