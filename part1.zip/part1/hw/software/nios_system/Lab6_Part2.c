/*
 * Lab6_Part2.c
 *
 *  Created on: Apr 4, 2022
 *      Author: er6400
 */

#include "io.h"
#include <stdio.h>
#include "system.h"

// create standard embedded type definitions
typedef   signed char   sint8;              // signed 8 bit values
typedef unsigned char   uint8;              // unsigned 8 bit values
typedef   signed short  sint16;             // signed 16 bit values
typedef unsigned short  uint16;             // unsigned 16 bit values
typedef   signed long   sint32;             // signed 32 bit values
typedef unsigned long   uint32;             // unsigned 32 bit values
typedef         float   real32;             // 32 bit real values

volatile uint32 *ledsBase_ptr     = (uint32 *) LEDS_BASE;
volatile uint32 *key1Base_ptr	   = (uint32*)KEY1_BASE;
uint32 *infRam_ptr = (uint32*)INFERRED_RAM_0_BASE;

//temp storage
unsigned char led_val;

void bitReset(uint32 startAddress, uint32 numBytes, uint32 testData)
{

	uint32 ramTestLoc;

	for(int i=startAddress; i<numBytes; i++)
	{
		*(infRam_ptr + i) = testData;
	}
}

void bitTest32(uint32 startAddress, uint32 numBytes, uint32 testData)
{

	uint32 ramTestLoc;

	for(int i=startAddress; i<numBytes; i++)
	{
		*(infRam_ptr + i) = testData;
	}

	for(int i=startAddress; i<numBytes; i++)
	{
		ramTestLoc = *(infRam_ptr +i);

		if (ramTestLoc != testData)
		{
			*ledsBase_ptr = 0xFF;

		}
	}
}


int main(void)
/*****************************************************************************/
/* Main Program                                                              */
/*   Enables interrupts then loops infinitely                                */
/*****************************************************************************/
{
    /* this enables the NIOS II to accept a TIMER interrupt
     * and indicates the name of the interrupt handler */

	*ledsBase_ptr = 0x00;

	bitReset(INFERRED_RAM_0_BASE, 4096, 0x00);

    while(1)
    {
    	bitTest32(INFERRED_RAM_0_BASE, 4096, 0xE1E1E1E1);
    }

    return 0;
}

